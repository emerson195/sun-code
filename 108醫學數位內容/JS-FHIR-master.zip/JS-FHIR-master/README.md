# JS-FHIR
JS sample code for FHIR 

JSON introduction URL:
https://mos2718.github.io/W1/JS_object/Index.html
