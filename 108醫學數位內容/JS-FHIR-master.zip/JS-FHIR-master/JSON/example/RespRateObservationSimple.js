﻿var a =
{
  "resourceType": "Observation",
   "status": "final",
 
  "subject": {
    "reference": "Patient/1856173"
  },

  "effectiveDateTime": "2019-05-04T16:51:00Z",
  "valueQuantity": {
    "value": 28,
    "unit": "/min",
    "system": "http://unitsofmeasure.org",
    "code": "/min"
  }
}